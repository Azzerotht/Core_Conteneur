Config = {}

Config.Debug = false

Config.Dispatch = 'cd'
Config.PoliceJobs = {'police', 'lssd', 'sheriff', 'sahp'} 
Config.DispatchCode = '10-17'
Config.DispatchMessage = 'Suspicius person exiting container'

Config.RequiredItem = 'lockpick'

Config.ContainerCoords = {
    { coords = vector3(910.5751, -3039.4622, 5.9020) },
    { coords = vector3(1005.7899, -3095.9290, 5.9010) },
    { coords = vector3(1149.8953, -2987.3542, 5.9010) },
    { coords = vector3(845.1858, -3085.2563, 5.9008) },
    { coords = vector3(1048.6450, -2992.2795, 5.9010) },
}

Config.Reward = {
    'weapon_pistol',
    'at_suppressor_light',
    'paperbag'
}

Config.Cooldown = 120 

Config.TargetLabelBreak = 'Forcer le Conteneur' -- Libellé sur la cible pour forcer l'entrée
Config.TargetIconBreak = 'fa-solid fa-hammer' -- Icône sur la cible pour forcer l'entrée - https://fontawesome.com/icons

Config.TargetLabelExit = 'Sortir' -- Libellé sur la cible pour sortir
Config.TargetIconExit = 'fa-solid fa-door-open' -- Icône sur la cible pour sortir - https://fontawesome.com/icons

Config.TargetLabelBox = 'Caisse à Butin' -- Libellé sur la cible pour prendre le butin de la caisse
Config.TargetIconBox = 'fa-solid fa-box' -- Icône sur la cible pour prendre le butin de la caisse - https://fontawesome.com/icons

Config.TargetDistance = 2

Config.NotifyTitle = 'Objets Requis'
Config.NotifyDescription = 'Vous n\'avez pas l\'objet requis pour forcer l\'entrée dans le conteneur'

Config.FailTitle = 'Échec'
Config.FailDescription = 'Vous avez échoué à crocheter le conteneur'

Config.ProgressBarLabel = 'Ouverture de la Caisse'
